let timer;
let isRunning = false;
let time = 0; // time in milliseconds
let lapTimes = [];

// Elements
const timeDisplay = document.getElementById('timeDisplay');
const startStopButton = document.getElementById('startStop');
const resetButton = document.getElementById('reset');
const lapButton = document.getElementById('lap');
const lapTimesList = document.getElementById('lapTimes');

// Functions
function formatTime(ms) {
  const date = new Date(ms);
  return date.toISOString().slice(11, 23); // Extracts HH:mm:ss.sss
}

function updateDisplay() {
  timeDisplay.textContent = formatTime(time);
}

function startStopwatch() {
  if (isRunning) {
    clearInterval(timer);
    isRunning = false;
    startStopButton.textContent = 'Start';
  } else {
    timer = setInterval(() => {
      time++;
      updateDisplay();
    }, 1);
    isRunning = true;
    startStopButton.textContent = 'Pause';
  }
}

function resetStopwatch() {
  clearInterval(timer);
  isRunning = false;
  time = 0;
  updateDisplay();
  lapTimes = [];
  lapTimesList.innerHTML = '';
  startStopButton.textContent = 'Start';
}

function recordLap() {
  if (isRunning) {
    lapTimes.push(formatTime(time));
    const lapItem = document.createElement('li');
    lapItem.textContent = `Lap ${lapTimes.length}: ${formatTime(time)}`;
    lapTimesList.appendChild(lapItem);
  }
}

// Event Listeners
startStopButton.addEventListener('click', startStopwatch);
resetButton.addEventListener('click', resetStopwatch);
lapButton.addEventListener('click', recordLap);

// Initialize
updateDisplay();
